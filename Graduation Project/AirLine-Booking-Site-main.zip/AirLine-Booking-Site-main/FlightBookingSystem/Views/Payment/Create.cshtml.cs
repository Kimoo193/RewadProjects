using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FlightBookingSystem.Views.Payment
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
