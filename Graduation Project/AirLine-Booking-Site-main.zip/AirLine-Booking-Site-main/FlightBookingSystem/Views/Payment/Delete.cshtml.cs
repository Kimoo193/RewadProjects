using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FlightBookingSystem.Views.Payment
{
    public class DeleteModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
